from __future__ import annotations

import random
import json
import hashlib

import numpy as np
import polars as pl
import pytest
import torch
from torch import nn
from torch.utils.data import TensorDataset
from torch.utils.data.distributed import DistributedSampler

from sic_cu.losses import PhysicsLossComputer
from sic_cu.eval import energy_v5
from sic_cu.config import PROJECT_ROOT
from sic_cu.physics.collocation import sample_collocation
from sic_cu.physics.materials import load_materials
from sic_cu.physics.resolution import load_resolved_boundary_conditions
from sic_cu.train import common
from sic_cu.train import multifidelity


def test_training_state_restores_optimizer_freeze_sampler_and_random_sources(tmp_path) -> None:
    torch.manual_seed(19)
    np.random.seed(19)
    random.seed(19)
    model = nn.Linear(2, 1)
    model.bias.requires_grad_(False)
    optimizer = torch.optim.AdamW([model.weight], lr=0.01)
    loss = model(torch.ones(2, 2)).square().mean()
    loss.backward()
    optimizer.step()
    sampler = DistributedSampler(TensorDataset(torch.arange(7)), num_replicas=1, rank=0)
    sampler.set_epoch(4)
    checkpoint = tmp_path / "阶段末.pt"
    common.save_training_state(
        checkpoint, model, optimizer, stage="校正", epoch=4,
        samplers={"观测": sampler}, budget={"轮次上限": 10},
    )
    expected = (torch.rand(3), np.random.rand(3), random.random())
    original_weight = model.weight.detach().clone()
    original_step = optimizer.state[model.weight]["step"].clone()

    with torch.no_grad():
        model.weight.add_(10)
    model.bias.requires_grad_(True)
    sampler.set_epoch(9)
    torch.rand(10)
    np.random.rand(10)
    random.random()
    restored = common.load_training_state(
        checkpoint, model, optimizer, samplers={"观测": sampler}
    )

    assert restored["stage"] == "校正"
    assert restored["epoch"] == 4
    assert restored["budget"] == {"轮次上限": 10}
    assert torch.equal(model.weight, original_weight)
    assert model.bias.requires_grad is False
    assert sampler.epoch == 4
    assert torch.equal(optimizer.state[model.weight]["step"], original_step)
    assert torch.equal(torch.rand(3), expected[0])
    assert np.array_equal(np.random.rand(3), expected[1])
    assert random.random() == expected[2]
    assert not (tmp_path / "阶段末.pt.tmp").exists()


def test_training_state_rejects_historical_model_only_checkpoint(tmp_path) -> None:
    checkpoint = tmp_path / "历史.pt"
    torch.save({"model_state": nn.Linear(2, 1).state_dict()}, checkpoint)
    model = nn.Linear(2, 1)
    optimizer = torch.optim.AdamW(model.parameters())
    with pytest.raises(ValueError, match="training state"):
        common.load_training_state(checkpoint, model, optimizer)


def test_collocation_subpackages_preserve_paired_interface_and_point_budget() -> None:
    batch = sample_collocation(8, torch.device("cpu"), seed=11)
    packages = common.split_collocation(batch, 3)
    assert len(packages) == 3
    for name in batch.__dataclass_fields__:
        original = getattr(batch, name)
        assert torch.equal(torch.cat([getattr(part, name) for part, _ in packages]), original)
    for part, ratio in packages:
        assert len(part.interface_sic) == len(part.interface_copper) == len(part.interface_normals)
        assert ratio == pytest.approx(len(part.interior) / len(batch.interior))
    assert sum(weight for _, weight in packages) == pytest.approx(1.0)


def test_collocation_subpackages_reject_more_parts_than_interface_pairs() -> None:
    batch = sample_collocation(4, torch.device("cpu"), seed=3)
    with pytest.raises(ValueError, match="subpackages"):
        common.split_collocation(batch, 5)


class SmallTemperatureField(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.coefficient = nn.Parameter(torch.tensor(0.3))

    def forward(self, coordinates: torch.Tensor) -> torch.Tensor:
        r, z, t, power = coordinates[:, :1], coordinates[:, 1:2], coordinates[:, 2:3], coordinates[:, 3:4]
        return 295.15 + self.coefficient * (r.square() + z.square() + t * power * 1e-4)


def test_weighted_subpackages_match_full_physics_loss_and_gradient() -> None:
    batch = sample_collocation(8, torch.device("cpu"), seed=17)
    model = SmallTemperatureField()
    physics = PhysicsLossComputer(load_materials(), load_resolved_boundary_conditions())
    full = physics(model, batch)["physics_total"]
    full_gradient = torch.autograd.grad(full, model.coefficient)[0]
    weighted = sum(
        weight * physics(model, part)["physics_total"]
        for part, weight in common.split_collocation(batch, 3)
    )
    weighted_gradient = torch.autograd.grad(weighted, model.coefficient)[0]
    assert torch.allclose(weighted, full, rtol=1e-5, atol=1e-6)
    assert torch.allclose(weighted_gradient, full_gradient, rtol=1e-5, atol=1e-6)


def test_physics_backward_adds_to_existing_observation_gradient() -> None:
    batch = sample_collocation(8, torch.device("cpu"), seed=23)
    model = SmallTemperatureField()
    optimizer = torch.optim.AdamW(model.parameters(), lr=0.01)
    physics = PhysicsLossComputer(load_materials(), load_resolved_boundary_conditions())
    data_loss = model(batch.initial).square().mean()
    optimizer.zero_grad(set_to_none=True)
    data_loss.backward()
    observation_gradient = model.coefficient.grad.detach().clone()
    expected = observation_gradient + torch.autograd.grad(
        physics(model, batch)["physics_total"], model.coefficient
    )[0]

    common.physics_backward(model, optimizer, physics, batch)

    assert torch.allclose(model.coefficient.grad, expected, rtol=1e-5, atol=1e-5)


def test_locked_b0_start_uses_manifest_and_preserves_current_physics_semantics() -> None:
    root = PROJECT_ROOT / "reports/runs/sic-cu-v2-gpu1-20260908T072729Z-r2"
    lf = root / "deeponet_pinn_lf_seed0/best.pt"
    hf = root / "deeponet_pinn_mf_seed0/best.pt"
    checkpoint = multifidelity.validate_locked_b0_start(hf, lf, seed=0)
    assert checkpoint["epoch"] == 579
    assert checkpoint["seed"] == 0
    assert checkpoint["provenance"]["test_labels_consumed"] is False


def test_locked_b0_start_rejects_incorrect_seed() -> None:
    root = PROJECT_ROOT / "reports/runs/sic-cu-v2-gpu1-20260908T072729Z-r2"
    with pytest.raises(ValueError, match="locked B0"):
        multifidelity.validate_locked_b0_start(
            root / "deeponet_pinn_mf_seed0/best.pt",
            root / "deeponet_pinn_lf_seed0/best.pt", seed=1,
        )


def test_schedule_comparison_requires_locked_b0_and_frozen_lf() -> None:
    with pytest.raises(ValueError, match="locked B0"):
        multifidelity.train_multifidelity(
            "unused.pt", "unused", correction_epochs=1, joint_epochs=0,
            physics_schedule="mixed_every_five",
        )


def test_new_config_snapshot_includes_only_persistent_main_plan_hash(tmp_path) -> None:
    snapshot = common.write_config_snapshot(tmp_path)
    main_plan = PROJECT_ROOT / "多保真DeepONet预测精度优化总计划与执行台账.md"
    hashes = json.loads((snapshot / "sha256.json").read_text(encoding="utf-8"))
    assert hashes[main_plan.name] == hashlib.sha256(main_plan.read_bytes()).hexdigest()


def test_energy_terms_chinese_mapping_preserves_original_balance_and_denominator() -> None:
    source = pl.read_csv(PROJECT_ROOT / "reports/development_v5/m2_energy_terms.csv")
    mapped, aggregate = energy_v5.chinese_energy_terms(source, order=64)
    assert mapped.height == 30
    assert "原定义相对平衡" in mapped.columns
    assert "原定义相对平衡分母_瓦" in mapped.columns
    assert "绝对平衡_瓦" in mapped.columns
    assert aggregate["绝对平衡宏均值_瓦"] == pytest.approx(908.4290536194341)
    assert aggregate["绝对平衡95分位_瓦"] == pytest.approx(1851.6758955264)
    assert mapped["平衡_瓦"].to_list() == source.filter(
        pl.col("quadrature_order") == 64
    )["balance_w"].to_list()
