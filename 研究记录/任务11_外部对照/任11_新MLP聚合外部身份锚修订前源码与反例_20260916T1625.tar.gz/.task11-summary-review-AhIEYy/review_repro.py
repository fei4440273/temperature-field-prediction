"""Only synthetic review diagnostics; never formal execution evidence."""

import json
import runpy
from pathlib import Path

import polars as pl

from sic_cu.config import PROJECT_ROOT
from sic_cu.data.common import sha256_file


HELPERS = runpy.run_path(str(PROJECT_ROOT / "tests/test_task11_mlp_hf_summary.py"))
evidence = HELPERS["evidence"]


def test_self_consistent_resealed_watt_drift_is_currently_accepted(evidence, monkeypatch):
    directory = Path(evidence["directories"][0]["directory"])
    raw_path = directory / "原始能量.jsonl"
    old_sha = sha256_file(raw_path)
    rows = [json.loads(line) for line in raw_path.read_text().splitlines()]
    old_cooling = rows[0]["cooling_heat_w"]
    for row in rows[:2]:
        row["cooling_heat_w"] += 1.0
        row["convection_heat_w"] -= 1.0
    raw_path.write_text("".join(json.dumps(row) + "\n" for row in rows))
    csv_path = directory / "指标明细.csv"
    frame = pl.read_csv(csv_path).with_columns(
        pl.when((pl.col("功率_瓦") == 55.0) & (pl.col("时刻_秒") == 1.0))
        .then(pl.col("水冷散热_瓦") + 1.0).otherwise(pl.col("水冷散热_瓦"))
        .alias("水冷散热_瓦"),
        pl.when((pl.col("功率_瓦") == 55.0) & (pl.col("时刻_秒") == 1.0))
        .then(pl.col("对流散热_瓦") - 1.0).otherwise(pl.col("对流散热_瓦"))
        .alias("对流散热_瓦"),
    )
    frame.write_csv(csv_path)
    HELPERS["_reseal"](directory)
    result = HELPERS["_execute"](evidence, monkeypatch)
    assert sha256_file(raw_path) != old_sha
    assert rows[0]["cooling_heat_w"] == old_cooling + 1.0
    assert result["统计约定"]["原件及完整资格审核前后相等"] is True
    assert evidence["output"].is_dir()
    print("REPRO_WATT_DRIFT_ACCEPTED old_raw_sha=" + old_sha
          + " new_raw_sha=" + sha256_file(raw_path))


def test_output_under_other_formal_training_tree_is_currently_accepted(evidence, monkeypatch):
    other_tree = evidence["root"] / "研究记录/任务07_正式五种子重训/正式HF_seed0"
    other_tree.mkdir(parents=True)
    evidence["output"] = other_tree / "不应落入旧正式训练树的聚合"
    result = HELPERS["_execute"](evidence, monkeypatch)
    assert result["统计约定"]["原件及完整资格审核前后相等"] is True
    assert evidence["output"].is_dir()
    print("REPRO_OTHER_FORMAL_TREE_ACCEPTED=" + str(evidence["output"]))
